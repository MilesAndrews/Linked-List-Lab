#include "slist.h"

/*
Class Library File
*/


// Constructor
Llist::Llist(){
  first = NULL;
}
// Destructor
Llist::~Llist(){}
// add(value)				//Adds a new value to the end of this list.
void Llist::add(Airport* ba){
  Node* newNode = new Node(ba);
  if (nodes == 0){
    first = newNode;
  }
  else{
    Node * nextNode = first;
    while(nextNode->nextNode != NULL){
      nextNode = nextNode->nextNode;
    }
    nextNode->nextNode = newNode;
  }
  nodes++;
}
// clear()					//Removes all elements from this list.
void Llist::clear(){
  first = NULL;
}
// equals(list)				//Returns true if the two lists contain the same elements in the same order.
bool Llist::equals(Llist l1){
  Node* curr1 = first;
  Node* curr2 = l1.first;

  while(curr1 != NULL && curr2 != NULL){
    if (curr1->data->code != curr2->data->code || curr1->data->latitude != curr2->data->latitude || curr1->data->longitude != curr2->data->longitude){
      return false;
    }

    curr1 = curr1->nextNode;
    curr2 = curr2->nextNode;
  }
  return curr1 == nullptr && curr2 == nullptr;
}
//get(index)				//Returns the element at the specified index in this list.
Airport Llist::get(int indx){
  Node * nextNode = first;
  Airport curr;
  int track = 0;
  while (track <= indx && nextNode != NULL){
    track++;
    curr = *(nextNode->data);
    nextNode = nextNode->nextNode;
  }
  return curr;
}
//insert(index, value)		//Inserts the element into this list before the specified index.
void Llist::insert(int indx, Airport* ba){
  if (indx < 0){
    return;
  }

  Node* curr = first;
  int i = 0;
  while (curr != nullptr && indx - 1){
    curr = curr->nextNode;
    i++;
  }

  if (curr == nullptr && indx > 0){
    return;
  }

  Node* newNode = new Node(ba);

  if (indx == 0){
    newNode->nextNode = first;
    first = newNode;
  }
  else{
    newNode->nextNode = curr->nextNode;
    curr->nextNode = newNode;
  }
}
  
//exchg(index1, index2)		//Switches the payload data of specified indexex.
void Llist::exchg(int indx1, int indx2){
  if (indx1 == indx2 || indx1 < 0 || indx2 < 0){
    return;
  }

  Node* curr1 = first;
  int i = 0;

  while (curr1 != nullptr && i < indx1){
    curr1 = curr1->nextNode;
    i++;
  }

  Node* curr2 = first;
  i = 0;

  while (curr2 != nullptr && i < indx2){
    curr2 = curr2->nextNode;
    i++;
  }
  if (curr1 == nullptr || curr2 == nullptr){
    std::swap(curr1->data, curr2->data);
  }
}
//swap(index1,index2)		//Swaps node located at index1 with node at index2
void Llist::swap(int indx1, int indx2){
  if (indx1 < 0 || indx2 < 0 || indx1 == indx2){
    return;
  }

  if (indx2 < indx1){
    std::swap(indx1, indx2);
  }

  Node* prev1 = nullptr;
  Node* post1 = first;
  for (int i = 0; post1 != nullptr && i <= indx1; i++){
    if (i <= indx1 - 2){
      prev1 = post1;
    }
    post1 = post1->nextNode;
  }

  Node* prev2 = nullptr;
  Node* post2 = first;
  for (int i = 0; post2 != nullptr && i < indx2; i++){
    if (i <= indx2 - 2){
      prev2 = post2;
    }
    post2 = post2->nextNode;
  }

  if (post1 == nullptr || post2 == nullptr){
    if (prev1 == nullptr){
      prev1->nextNode = post2;
    }
    else {
      first = post2;
    }
    if (prev2 != nullptr){
      prev2->nextNode = post1;
    }
    else {
      first = post1;
    }
    std::swap(post1->nextNode, post2->nextNode);
  }
}
// isEmpty()				//Returns true if this list contains no elements.
bool Llist::isEmpty(){
  return first == nullptr;
}
// remove(index)			//Removes the element at the specified index from this list.
void Llist::remove(int indx){
  if (indx == 0){
    first = first->nextNode;
    return;
  }
  Node* temp = first;
  int i = 0;
  while (temp != nullptr && i < indx - 1){
    temp = temp->nextNode;
    i++;
  }
  temp->nextNode = temp->nextNode->nextNode;
}
// set(index, value)		//Replaces the element at the specified index in this list with a new value.
void Llist::set(int indx, Airport& va){
  if (indx == 0){
    first->data = &va;
    return;
  }
  Node* nextNode = first;
  Airport current;
  int i = 0;
  while (nextNode != nullptr && i < indx){
    nextNode = nextNode->nextNode;
    i++;
  }
  nextNode->data = &va;
}
// size()					//Returns the number of elements in this list.
int Llist::findSize(){
  int length = 0;
  Node* temp = first;
  while (temp != nullptr){
    temp = temp->nextNode;
    length++;
  }
  return length;
}
// DO NOT IMPLEMENT >>> subList(start, length)	//Returns a new list containing elements from a sub-range of this list.

// DO NOT IMPLEMENT >>> toString()				//Converts the list to a printable string representation.