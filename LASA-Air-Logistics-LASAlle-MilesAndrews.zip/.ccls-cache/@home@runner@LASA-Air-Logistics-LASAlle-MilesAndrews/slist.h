#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

using namespace std;

class Airport {
  public:
    char code[5];
    double longitude;
    double latitude;
};

class Node {
  public:
    Airport* data;
    Node* nextNode;

    Node() : data(nullptr), nextNode(nullptr) {}
    Node(Airport* ba) : data(ba), nextNode(nullptr) {}
    Node(Airport* ba, Node* next) : data(ba), nextNode(next) {}

    void setNextNode(Node* next){
      nextNode = next;
    }

    Node* getNextNode(){
      return nextNode;
    }
  };
class Llist{
  public:
  Node* first;
  int nodes = 0;
  
  
  Llist();
  ~Llist();

  void add(Airport* ba);
  void clear();
  bool equals(Llist l1);
  Airport get(int indx);
  void insert(int indx, Airport* val);
  void exchg(int indx1, int indx2);
  void swap(int indx1, int indx2);
  bool isEmpty();
  void remove(int indx);
  void set(int indx, Airport& val);
  int findSize();
  string toString();
};