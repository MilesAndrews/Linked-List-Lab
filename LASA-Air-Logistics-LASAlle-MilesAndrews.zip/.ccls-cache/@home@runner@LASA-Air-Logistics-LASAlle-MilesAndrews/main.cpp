
//
//  main.cpp
//  LLTemplate
//
//  Created by James Shockey on 12/6/16.
//  Copyright © 2016 James Shockey. All rights reserved.
//


/*
 *
 *	Linked List lab.
 *	- Build a library for singly linked list.
 *	- Replace the airport array in main with a Linked List.
 *  - sort the array. 
 *	
 */


#include <iostream>
#include <fstream>
#include <cmath> 
#include "slist.h"
#include <cstring>
#include <cstdlib>

using namespace std;

ostream& operator << (ostream &s, Llist &l1){
  Node * nextNode = l1.first;
  bool top = true;
  while(nextNode != NULL){
    top = false;
    s << nextNode->data->code << "," << nextNode->data->latitude << "," << nextNode->data->longitude;

    if(nextNode->nextNode != NULL)
      s << endl;
    nextNode = nextNode->nextNode;
  }
  return s;
}



#define pi 3.14159265358979323846
#define earthRadiusKm 6371.0

// This function converts decimal degrees to radians
double deg2rad(double deg) {
  return (deg * pi / 180);
}

//  This function converts radians to decimal degrees
double rad2deg(double rad) {
  return (rad * 180 / pi);
}

double distanceEarth(double lat1d, double lon1d, double lat2d, double lon2d) {
  double lat1r, lon1r, lat2r, lon2r, u, v;
  lat1r = deg2rad(lat1d);
  lon1r = deg2rad(lon1d);
  lat2r = deg2rad(lat2d);
  lon2r = deg2rad(lon2d);
  u = sin((lat2r - lat1r)/2);
  v = sin((lon2r - lon1r)/2);
  return 2.0 * earthRadiusKm * asin(sqrt(u * u + cos(lat1r) * cos(lat2r) * v * v));
}

int main() {
  ifstream infile;
  char c[80];
  char code[10];
  double lati, longi;
  Llist airports;

  infile.open("airport-codes_US.csv", ifstream::in);

  if (infile.is_open()){
    while (infile.good()){
      Airport* current = new Airport();
      infile.getline(code, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      longi = atof(c);
      infile.getline(c, 350, ',');
      lati = atof(c);
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, ',');
      infile.getline(c, 350, '\n');

      strcpy(current->code, code);
      current->longitude = longi;
      current->latitude = lati;
      airports.add(current);
    }
    infile.close();
  }
  else {
    cout << "Error opening the file." << endl;
    return 1;
  }

  double farthest = 0;
  Airport farthestAir = airports.get(0);
  Llist airports100;

  for (int i = 0; i < airports.findSize(); i++){
    double currentDist = distanceEarth(30.19449997, -97.66989899, airports.get(i).latitude, airports.get(i).longitude);

    if (currentDist > farthest){
      farthest = currentDist;
      farthestAir = airports.get(i);
    }

    if (currentDist <100){
      Airport* temp = new Airport();
      strcpy(temp->code, airports.get(i).code);
      temp->longitude = airports.get(i).longitude;
      temp-> latitude = airports.get(i).latitude;
      airports100.add(temp);
    }
  }

  cout << "Farthest Airport: " << endl << farthestAir.code << ", " << farthest << endl;

  cout << "Airports within 100 miles of Austin Airport: " << endl << airports100;

  return 0;
}
/**
 * Returns the distance between two points on the Earth.
 * Direct translation from http://en.wikipedia.org/wiki/Haversine_formula
 * @param lat1d Latitude of the first point in degrees
 * @param lon1d Longitude of the first point in degrees
 * @param lat2d Latitude of the second point in degrees
 * @param lon2d Longitude of the second point in degrees
 * @return The distance between the two points in kilometers
 */


/*
	Provide sort routine on linked list
*/
